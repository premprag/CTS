
```

Setup ansible: `yum install ansible`

Configure mysql and setup a test db

`ansible-playbook -i hosts mysql.yml`

Configure apache

`ansible-playbook -i hosts apache.yml`

Only php

`ansible-playbook -i hosts apache.yml --tags "php"`

Configure tomcat

`ansible-playbook -i hosts tomcat.yml`

**Single Step Configuration**

`
ansible-playbook -c local -i hosts site.yml
``
